#include "LinkedList.h"

template <class T>
LinkedList<T>::LinkedList()
{
    header = new Node<T>;
    trailer = new Node<T>;
    init();
}

template <class T>
LinkedList<T>::LinkedList(LinkedList<T>& lis)
{
    header = new Node<T>;
    trailer = new Node<T>;
    init();
    lis.moveToStart();
    while(lis.getCurrNode() != lis.end())
    {
        append(lis.getCurrNode()->getData());
        lis.next();
    }
}

template <class T>
LinkedList<T>::~LinkedList()
{
    removeAll();
    delete header;
    delete trailer;
}

template <class T>
void LinkedList<T>::next()
{

    if(currNode != trailer)
        currNode = currNode->getNext();
}

template <class T>
void LinkedList<T>::prev()
{
    if(currNode->getPrev() != header)
        currNode = currNode->getPrev();
}

template <class T>
void LinkedList<T>::moveToStart()
{
    currNode = header->getNext();
}

template <class T>
void LinkedList<T>::moveToEnd()
{
    currNode = trailer;
}

template <class T>
void LinkedList<T>::moveToPos(int pos)
{
    moveToStart();
    if(pos >= currSize)
    {
        currNode = trailer;
    }
    else
    {
        int counter = 0;
        for(moveToStart(); getCurrNode() != end(); next())
        {
            if (counter == pos)
            {
                return;
            }
            counter++;
        }
    }
}

template <class T>
int LinkedList<T>::length() const
{
    return currSize;
}

template <class T>
T LinkedList<T>::value() const
{
    return currNode->getData();
}

template <class T>
bool LinkedList<T>::empty() const
{
    return(!currSize);
}

template <class T>
void LinkedList<T>::append (T elem)
{
    insert(trailer, elem);
    if (currNode == trailer)
        currNode = trailer->getPrev();
}

template <class T>
void LinkedList<T>::insert(const T& elem)
{
    insert(currNode, elem);
    prev();
}

template <class T>
T LinkedList<T>::remove()
{
    T xdata = currNode->getData();

    Node<T>* temp = currNode;

    currNode->getPrev()->setNext(currNode->getNext());
    currNode->getNext()->setPrev(currNode->getPrev());

    next();

    delete temp;
    currSize--;
    return xdata;
}

template <class T>
void LinkedList<T>::clear()
{
    moveToStart();
    while (currNode != end())
    {
        next();
        delete currNode->getPrev();
    }
    init();
}

template <class T>
Node<T>* LinkedList<T>::end() const
{
    return trailer;
}

template <class T>
Node<T>* LinkedList<T>::getCurrNode() const
{
    return currNode;
}

template <class T>
 void LinkedList<T>::insert(Node<T>* beforeMe, const T& elem)
 {
     Node<T>* new_node = new Node<T>(elem, beforeMe, beforeMe->getPrev());

     beforeMe->getPrev()->setNext(new_node);
     beforeMe->setPrev(new_node);

     currSize++;
 }

 template <class T>
 void LinkedList<T>::removeAll()
 {
     moveToStart();
     while (currNode != trailer)
     {
         next();
         delete currNode->getPrev();
     }
 }

 template <class T>
 void LinkedList<T>::init()
 {
    header->setNext(trailer);
    header->setPrev(NULL);

    trailer->setPrev(header);
    trailer->setNext(NULL);

    currNode = trailer;
    currSize = 0;
 }
