#include <iostream>
#include "StringSet.h"

using namespace std;

void ReadDoc(vector<string>& Document1, vector<string>& Doccument2, vector<string>& Query1);

int main()
{
    vector<string> Document1,Document2,Query1;
    ReadDoc(Document1,Document2,Query1);

    StringSet Doc1, Doc2, Query, Union, Intersection;

    Doc1.insert(Document1);
    cout << "Doc1: " << Doc1 << endl;
    Doc2.insert(Document2);
    cout << "Doc2: " << Doc2 << endl;
    Union = Doc1 + Doc2;
    cout << "Union: " <<  Union << endl;
    Query.insert(Query1);
    cout << "Query: " <<  Query << endl;
    cout << "Query size: " << Query.Size() << endl;
    Intersection = Query * Union;
    cout << "Found in union: " << Intersection.Size() << endl;
    double Simularity1 = Sim(Query,Doc1);
    cout << "Similarity to doc1: " <<  Simularity1 << endl;
    double Simularity2 = Sim(Query,Doc2);
    cout << "Similarity to doc2: " << Simularity2 << endl;











    return 0;
}

void ReadDoc(vector<string>& Document1, vector<string>& Document2, vector<string>& Query1){
    string temp;
    ifstream File1,File2,File3;
        File1.open("doc1.txt");
    if (File1.fail()){
        cout <<  "Error in opening File";
        exit(1);
    }

     while(File1 >> temp){
        Document1.push_back(temp);
    }
    File1.close();

    File2.open("doc2.txt");
    if (File2.fail()){

        cout <<  "Error in opening File";
        exit(1);
    }
     while(File2 >> temp){
        Document2.push_back(temp);
    }
    File2.close();

    File3.open("query.txt");
    if (File3.fail()){

        cout <<  "Error in opening File";
        exit(1);
    }
     while(File3 >> temp){
        Query1.push_back(temp);
    }

    File3.close();

}






