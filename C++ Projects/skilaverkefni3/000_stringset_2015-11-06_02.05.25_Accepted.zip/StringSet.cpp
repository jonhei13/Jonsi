#include "StringSet.h"

StringSet::StringSet(){



}

ostream& operator << (ostream& outs, const StringSet& S){
    for (unsigned int i = 0; i < S.Text.size(); i++){
        outs << S.Text[i] << " ";
    }
    return outs;
}


StringSet operator + (const StringSet& S, const StringSet& S2){
    // Finds Union between 2 documents
    StringSet Union;
    for (unsigned int i = 0; i < S.Text.size();i++){
        string temp = S.Text[i];
        Union.Text.push_back(temp);
    }
    for(unsigned int k = 0; k < S2.Text.size();k++){
        string temp = S2.Text[k];
        Union.Text.push_back(temp);
        }

    Union.Repitition();

    return Union;
}


StringSet operator * (const StringSet& S, const StringSet& S2){
     // Finds Intersection between 2 Documents
        StringSet Intersection;

        for (unsigned int i = 0; i < S.Text.size(); i++){
            for(unsigned int k = 0; k < S2.Text.size();k++){
                if (S.Text[i] == S2.Text[k]){
                    string temp;
                    temp = S.Text[i];
                    Intersection.Text.push_back(temp);
                }
            }

        }

    return Intersection;
}

void StringSet::insert(vector<string> word){

    for(unsigned int i = 0; i < word.size(); i++){
        string temp = word[i];
        Text.push_back(temp);
    }


    Repitition();
}

void StringSet::Repitition(){
    for (unsigned int i = 0; i < Text.size(); i++){
        for(unsigned int k = i+1; k < Text.size();k++){
            while(Text[i] == Text[k] && k < Text.size()){
                Text.erase(Text.begin() + k);
            }
        }
    }
}

int StringSet::Size(){

    int x = Text.size();

   return x;
}

double Sim(StringSet& S, StringSet& S2){
    // Finds simularity between Documents
    StringSet temp;

    temp = S * S2;
    double Union = temp.Size();
    double Doc1 = S.Size();
    double Doc2 = S2.Size();

    double Simularity = Union/(sqrt(Doc1)*sqrt(Doc2));


    return Simularity;
}

string StringSet::at(int i) const{
    //Returns string
    unsigned int b = i;
    for(unsigned int k = 0; k < Text.size(); k++){
        if (k == b)
            return Text[k];

    }
    return 0;

}


