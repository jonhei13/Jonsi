#ifndef STRINGSET_H
#define STRINGSET_H
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <cmath>

using namespace std;
class StringSet
{
    public:
        StringSet();
        void insert(vector<string> word);
        int Size();
        string at(int i) const;

        friend double Sim(StringSet& S, StringSet& S2);
        friend ostream& operator << (ostream& outs, const StringSet& S);
        friend StringSet operator + (const StringSet& S, const StringSet& S2);
        friend StringSet operator * (const StringSet& S, const StringSet& S2);
    private:
        void Repitition();
        vector<string>Text;
};

#endif // STRINGSET_H
